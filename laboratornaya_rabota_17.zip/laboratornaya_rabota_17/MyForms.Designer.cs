﻿namespace laboratornaya_rabota_17
{
    partial class MyForms
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.createATitlePage = new System.Windows.Forms.Button();
            this.createQuestionnare = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // createATitlePage
            // 
            this.createATitlePage.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.createATitlePage.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.createATitlePage.ImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.createATitlePage.Location = new System.Drawing.Point(41, 179);
            this.createATitlePage.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.createATitlePage.Name = "createATitlePage";
            this.createATitlePage.Size = new System.Drawing.Size(172, 102);
            this.createATitlePage.TabIndex = 16;
            this.createATitlePage.Text = "Создать титульный лист";
            this.createATitlePage.UseVisualStyleBackColor = false;
            this.createATitlePage.Click += new System.EventHandler(this.createATitlePage_Click);
            // 
            // createQuestionnare
            // 
            this.createQuestionnare.Location = new System.Drawing.Point(292, 179);
            this.createQuestionnare.Name = "createQuestionnare";
            this.createQuestionnare.Size = new System.Drawing.Size(207, 102);
            this.createQuestionnare.TabIndex = 26;
            this.createQuestionnare.Text = "Создать анкету";
            this.createQuestionnare.UseVisualStyleBackColor = true;
            this.createQuestionnare.Click += new System.EventHandler(this.createQuestionnare_Click);
            // 
            // MyForms
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(544, 440);
            this.Controls.Add(this.createQuestionnare);
            this.Controls.Add(this.createATitlePage);
            this.Name = "MyForms";
            this.Text = "MyForms";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button createATitlePage;
        private System.Windows.Forms.Button createQuestionnare;
    }
}
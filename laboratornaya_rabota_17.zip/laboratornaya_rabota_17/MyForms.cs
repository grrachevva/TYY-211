﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using wword;


namespace laboratornaya_rabota_17
{
    public partial class MyForms : Form
    {
        public MyForms()
        {
            InitializeComponent();
        }


        private void createQuestionnare_Click(object sender, EventArgs e)
        {
            Questionnaire form1 = new Questionnaire();
            form1.Show();
            this.Hide();
        }

        private void createATitlePage_Click(object sender, EventArgs e)
        {
            wordAutomation form2 = new wordAutomation();
            form2.Show();
            this.Hide();
        }
    }
}
